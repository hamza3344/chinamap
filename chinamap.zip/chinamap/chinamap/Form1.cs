﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LiveCharts.WinForms;

namespace chinamap
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GeoMap geomap = new GeoMap();
            Random random = new Random();
            Dictionary<string, double> values = new Dictionary<string, double>();
            values["1492"] = random.Next(0, 100);
            values["1493"] = random.Next(0, 100);
            values["1494"] = random.Next(0, 100);
            geomap.HeatMap = values;
            geomap.Hoverable = true;
            //link of xml file in description
            geomap.Source = $"{Application.StartupPath}\\china.xml";
            this.Controls.Add(geomap);
            geomap.Dock = DockStyle.Fill;
        }
    }
}
